export interface User {
    EmpId: number;
    email: string;
    password: string;
    role: string;
    Name:string;
}
