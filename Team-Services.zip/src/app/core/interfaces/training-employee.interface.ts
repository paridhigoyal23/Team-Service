export interface Employee{
    id:number;
    Name:string;
    EmpId:string;
}