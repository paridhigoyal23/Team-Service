export class AppConstants {
    public static readonly USER_INFO = "userInfo";
    public static readonly DATA_SAVED = "dataSaved";
    public static readonly TrainingData_Saved="trainingDataSaved"
}
