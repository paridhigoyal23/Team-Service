import { Component,OnInit } from '@angular/core';
import { Data } from '@angular/router';
import * as XLXS from 'xlsx';
@Component({
  selector: 'app-excel-read',
  templateUrl: './excel-read.component.html',
  styleUrls: ['./excel-read.component.css']
})
export class ExcelReadComponent implements OnInit {
  data:[][];
  constructor(){}
ngOnInit(): void {
  
}
onFileChange(evt:any){
  const target:DataTransfer= <DataTransfer>(evt.target);
  if(target.files.length!==1) throw new Error('Cannot use multiple files')
  const reader:FileReader=new FileReader();
  reader.onload=(e:any)=>{
    const bstr:string=e.target.result;
    const wb:XLXS.WorkBook=XLXS.read(bstr,{type:'binary'});
    const wsname:string=wb.SheetNames[0];
    const ws:XLXS.WorkSheet=wb.Sheets[wsname];
    console.log(ws);
    this.data=(XLXS.utils.sheet_to_json(ws,{header:1}));
    console.log(this.data)

  };
  reader.readAsBinaryString(target.files[0]);
 }
}
