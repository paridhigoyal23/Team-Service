import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExcelReadComponent } from './excel-read.component';

describe('ExcelReadComponent', () => {
  let component: ExcelReadComponent;
  let fixture: ComponentFixture<ExcelReadComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ExcelReadComponent]
    });
    fixture = TestBed.createComponent(ExcelReadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
